package ifTest;
//5번 : 조건문(if문)
public class IfTest01 {
	public static void main(String[] args) {
		System.out.println("1번");
		
		if(true) {
			System.out.println("2번");
		}
		
		if(10 < 10) {
			System.out.println("3번");
		}
		
		System.out.println("4번");
	}
}
