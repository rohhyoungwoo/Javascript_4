package forTest;
// 10번 : 반복문(for문)
public class ForTest01 {
	public static void main(String[] args) {
		
//		for(초기식; 조건식; 증감식) {
//			
//		}
		
		for(int i = 0; i < 10; i++) {
//			System.out.println("행복하다");
			System.out.println(i);
		}
		
		System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10);
		
	}
}
