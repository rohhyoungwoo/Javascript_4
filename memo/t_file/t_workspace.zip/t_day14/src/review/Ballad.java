package review;

public class Ballad extends Music{

	@Override
	void mode() {
		System.out.println("발라드 모드");
	}
	
	void onlyBallad() {
		System.out.println("onlyBallad 실행");
	}
	
}
