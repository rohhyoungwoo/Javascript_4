package review;

public class Music {
	//메소드
	void mode() {
		
	}
}
