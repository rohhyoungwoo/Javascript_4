package abstractTest2;
//5번 : 추상클래스와 강제성
public abstract class Animal {
	//필드
	String name;
	int age;
	
	//메소드
	abstract void crying();
}
