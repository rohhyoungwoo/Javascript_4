package abstractTest2;
//5번 : 추상클래스와 강제성
public class Dog extends Animal {

	@Override
	void crying() {
		System.out.println("멍멍!!");
	}

}
