//package classInterface;
////13번 : 상속과 구현은 별개이다
//
//class Parent {
//	void parentMethod() {
//		System.out.println("부모 클래스의 메소드");
//	}
//}
//
//interface InterfaceA {
//	void methodA();
//}
//
//interface InterfaceB {
//	void methodB();
//}
//
//class Child extends Parent implements InterfaceA, InterfaceB {
//
//	@Override
//	public void methodB() {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public void methodA() {
//		// TODO Auto-generated method stub
//
//	}
//
//}
//
//public class ExtendsImpl {
//	public static void main(String[] args) {
//
//	}
//}
