package interfaceTest3;

public class Main {
	public static void main(String[] args) {
		Child c = new Child();
		System.out.println(c);
		c.greet();
	}
}
