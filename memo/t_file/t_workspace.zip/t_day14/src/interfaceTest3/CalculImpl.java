package interfaceTest3;

public class CalculImpl implements Calculator{
	

}
