package interfaceTest3;

public interface Utility {
	static void printMsg(String msg) {
		System.out.println("Utility 메시지 : " + msg);
	}
}
