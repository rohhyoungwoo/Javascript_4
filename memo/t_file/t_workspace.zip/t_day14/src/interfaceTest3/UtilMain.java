package interfaceTest3;

public class UtilMain {
	public static void main(String[] args) {
		Utility.printMsg("안녕");
	}
}
