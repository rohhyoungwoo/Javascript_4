package interfaceTest1;
//6번 : 인터페이스 선언
public interface Inter {
	//상수, 추상메소드
	public final static int VAR1 = 10;
	int VAR2 = 20;
	public abstract void method1();
	void method2();
	
}
