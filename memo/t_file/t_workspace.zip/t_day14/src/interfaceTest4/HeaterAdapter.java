package interfaceTest4;

public abstract class HeaterAdapter implements Heater{

	@Override
	public void turbo() {
		
		
	}
	
}
