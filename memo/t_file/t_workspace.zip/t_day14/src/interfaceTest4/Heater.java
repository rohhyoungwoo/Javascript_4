package interfaceTest4;

public interface Heater {
	//히터 - 켜기, 끄기, 터보모드
	void on();
	void off();
	void turbo();
	
}
