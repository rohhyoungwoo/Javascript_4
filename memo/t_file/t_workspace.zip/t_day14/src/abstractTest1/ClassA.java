package abstractTest1;
//1번 : 일반 클래스
public class ClassA {
	//메소드
	void method1() {
		System.out.println("메소드1 실행");
	}
}
