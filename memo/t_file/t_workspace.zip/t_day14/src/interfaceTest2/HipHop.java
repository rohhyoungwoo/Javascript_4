package interfaceTest2;

public class HipHop implements Music{

	@Override
	public void mode() {
		System.out.println("힙합모드");
	}
	
	void onlyHipHop() {
		System.out.println("onlyHipHop 실행");
	}

}
