package interfaceTest2;

public interface Music {
	// 구현하지 않은 mode메소드 만들기
	void mode();
}
