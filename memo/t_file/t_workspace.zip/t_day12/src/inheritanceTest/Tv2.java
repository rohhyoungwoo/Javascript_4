package inheritanceTest;
//7번 : 상속 기초
public class Tv2 extends Tv{
	//메소드
	void netflix() {
		System.out.println("넷플릭스 모드를 켭니다");
	}
}
