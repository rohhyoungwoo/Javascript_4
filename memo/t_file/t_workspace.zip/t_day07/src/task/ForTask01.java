//본인이름
package task;

public class ForTask01 {
	public static void main(String[] args) {
		//1. 1 ~ 100까지 출력 tab키만큼 간격 띄우고 10마다 줄바꿈
		// 1	2	3	4	5	6	7	8	9	10
		//11	12	13..						20
		//21	22	........					30
		//91	...								100
		
		//2. A~F출력
		int a = 'A';
		
		//3. aBcDeFgHiJkLmNoPqRsTuVwXyZ 출력
		int i = 0;
		
		//4.1) 1부터 100까지 숫자 중 3의 배수 또는 5의 배수만 한 줄에 5개씩 띄어쓰기로 구분되도록 출력
		//	2) 3의 배수 또는 5의 배수 숫자들의 합을 구하기
		

		
	}

}
