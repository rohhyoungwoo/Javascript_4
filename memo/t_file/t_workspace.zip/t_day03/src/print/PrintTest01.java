package print;
//7번 : 출력메소드(println, print)

public class PrintTest01 {
	public static void main(String[] args) {
		System.out.println("오늘은 3일차 수업입니다.");
		System.out.println("4교시 중입니다.");
		System.out.print("출력메소드 연습중입니다.\n");
		System.out.print("출력메소드 println()은 소괄호안의 내용을 출력하고 줄바꿈되고"
				+ "\nprint()는 소괄호안의 내용을 출력하고 줄바꿈되지 않습니다.");
	}
}
